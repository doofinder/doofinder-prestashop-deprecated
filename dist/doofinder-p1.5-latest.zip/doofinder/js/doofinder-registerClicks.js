
$(document).on('ready', function(){
	var timer = setInterval(function(){
		var layer;
		if(typeof(dfClassicLayers) !== undefined){
			layer = dfClassicLayers[0];
		}
		else{
	        layer = dfFullscreenLayers[0];
		}	
		if(typeof(layer.layerOptions) == undefined){
			return;
		}
		else{
			hashid = layer.layerOptions.hashid;
			var cookie = Cookies.getJSON('dfhit' + hashid);
			var query = cookie.query;
			var productContainer = $('.product-container');

			productContainer.on('click', 'a', function(){
				// HERE YOU GET THE PRODUCT ID
				var productId = productContainer.find('[data-id-product]').first().data('id-product') + '';
				console.log(productId);
				if(productId)
					layer.controller.registerClick(productId, {query: query});
			});
			clearInterval(timer);
		}
	}, 300);


});